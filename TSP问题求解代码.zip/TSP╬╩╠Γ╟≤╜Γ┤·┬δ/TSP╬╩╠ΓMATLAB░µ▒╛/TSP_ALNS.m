function alns_solution = TSP_ALNS()

    % 从Excel文件中读取数据
    function data = read_excel_file(file_path)
        data = xlsread(file_path);
    end

    % 处理节点信息
    function city_location = process_node_info(data)
        city_location = data(:, 2:3);
    end

    % 生成距离矩阵
    function dist_mat = city_distance(city_location)
        city_cnt = size(city_location, 1);
        dist_mat = zeros(city_cnt, city_cnt);
        for i = 1:city_cnt
            for j = 1:city_cnt
                if i == j
                    dist_mat(i, j) = 1000000;
                else
                    dist_mat(i, j) = sqrt((city_location(i, 1) - city_location(j, 1))^2 + (city_location(i, 2) - city_location(j, 2))^2);
                end
            end
        end
    end

    % 随机删除N个城市
    function removed_cities = random_destroy(x, destroy_city_cnt)
        removed_index = randperm(length(x), destroy_city_cnt);
        removed_cities = x(removed_index);
        x(removed_index) = [];
    end

    % 删除距离最大的N个城市
    function removed_cities = max_n_destroy(x, destroy_city_cnt, dist_mat)
        [~, sorted_index] = sort([0; sum(dist_mat(x(1:end-1), x(2:end)), 2) + dist_mat(x(end), x(1))], 'descend');
        removed_cities = x(sorted_index(1:destroy_city_cnt));
        x(sorted_index(1:destroy_city_cnt)) = [];
    end

    % 随机删除连续的N个城市
    function removed_cities = continue_n_destroy(x, destroy_city_cnt)
        removed_index = randi(length(x)-destroy_city_cnt);
        removed_cities = x(removed_index+1:removed_index+destroy_city_cnt);
        x(removed_index+1:removed_index+destroy_city_cnt) = [];
    end

    % destroy操作
    function [x, removed_cities] = destroy(flag, x, destroy_city_cnt, dist_mat)
        removed_cities = []; % 初始化 removed_cities

        % 根据 flag 执行不同的 destroy 操作，同时设置 removed_cities 的值

        switch flag
            case 0
                removed_cities = random_destroy(x, destroy_city_cnt);
            case 1
                removed_cities = max_n_destroy(x, destroy_city_cnt, dist_mat);
            case 2
                removed_cities = continue_n_destroy(x, destroy_city_cnt);
        end
    end

    % 随机插入
    function x = random_insert(x, removed_cities)
        insert_indices = randperm(length(x), length(removed_cities));
        x = [x(insert_indices), removed_cities];
    end


    % 贪心插入
    function x = greedy_insert(x, removed_cities, dist_mat)
        dis = inf;
        insert_index = -1;

        for i = 1:length(removed_cities)
            for j = 1:length(x)+1
                new_x = [x(1:j-1), removed_cities(i), x(j:end)];
                if dis_cal(new_x, dist_mat) < dis
                    dis = dis_cal(new_x, dist_mat);
                    insert_index = j;
                end
            end
            x = [x(1:insert_index-1), removed_cities(i), x(insert_index:end)];
            dis = inf;
        end
    end

    % repair操作
    function x = repair(flag, x, removed_cities, dist_mat)
        switch flag
            case 0
                x = random_insert(x, removed_cities);
            case 1
                x = greedy_insert(x, removed_cities, dist_mat);
        end
    end

    % 选择destroy算子
    function [x, removed_cities, destroy_operator] = select_and_destroy(destroy_w, x, destroy_city_cnt, dist_mat)
        destroy_operator = roulette_wheel_selection(destroy_w);

        removed_cities = destroy(destroy_operator, x, destroy_city_cnt, dist_mat);
    end

    % 选择repair算子
    function [x, repair_operator] = select_and_repair(repair_w, x, removed_cities, dist_mat)
        repair_operator = roulette_wheel_selection(repair_w);

        x = repair(repair_operator, x, removed_cities, dist_mat);
    end

    % 轮盘赌选择算子
    function operator_index = roulette_wheel_selection(weights)
        cumulative_prob = cumsum(weights) / sum(weights);
        r = rand();
        for i = 1:length(cumulative_prob)
            if r <= cumulative_prob(i)
                operator_index = i;
                return;
            end
        end
    end

    % ALNS主程序
    function history_best_x = calc_by_alns(dist_mat, max_iter, T, a, lambda_rate)
        destroy_city_cnt = floor(length(dist_mat) * 0.4);
        destroy_w = [1, 1, 1];
        repair_w = [1, 1];
        destroy_cnt = [0, 0, 0];
        repair_cnt = [0, 0];
        destroy_score = [1, 1, 1];
        repair_score = [1, 1];

        removed_cities = randperm(length(dist_mat));
        x = removed_cities;
        repair(1, x, removed_cities, dist_mat);

        history_best_x = x;

        cur_iter = 0;
        while cur_iter < max_iter
            [destroyed_x, remove, destroy_operator_index] = select_and_destroy(destroy_w, x, destroy_city_cnt, dist_mat);
            destroy_cnt(destroy_operator_index) = destroy_cnt(destroy_operator_index) + 1;

            [new_x, repair_operator_index] = select_and_repair(repair_w, destroyed_x, remove, dist_mat);
            repair_cnt(repair_operator_index) = repair_cnt(repair_operator_index) + 1;

            if dis_cal(new_x, dist_mat) <= dis_cal(x, dist_mat)
                x = new_x;
                if dis_cal(new_x, dist_mat) <= dis_cal(history_best_x, dist_mat)
                    % 调用两边逐次修正算子并更新最佳路径
                    new_x = successive_correction_operators(new_x, dist_mat);
                    history_best_x = new_x;
                    destroy_score(destroy_operator_index) = 1.5;
                    repair_score(repair_operator_index) = 1.5;
                else
                    destroy_score(destroy_operator_index) = 1.2;
                    repair_score(repair_operator_index) = 1.2;
                end
            else
                if rand() < exp((dis_cal(x, dist_mat) - dis_cal(new_x, dist_mat)) / T)
                    x = new_x;
                    destroy_score(destroy_operator_index) = 0.8;
                    repair_score(repair_operator_index) = 0.8;
                else
                    destroy_score(destroy_operator_index) = 0.5;
                    repair_score(repair_operator_index) = 0.5;
                end
            end

            destroy_w(destroy_operator_index) = ...
                destroy_w(destroy_operator_index) * lambda_rate + ...
                (1 - lambda_rate) * destroy_score(destroy_operator_index) / destroy_cnt(destroy_operator_index);

            repair_w(repair_operator_index) = ...
                repair_w(repair_operator_index) * lambda_rate + ...
                (1 - lambda_rate) * repair_score(repair_operator_index) / repair_cnt(repair_operator_index);

            T = a * T;

            cur_iter = cur_iter + 1;
            disp(['cur_iter: ', num2str(cur_iter), ', best_f: ', num2str(dis_cal(history_best_x, dist_mat)), ', best_x: ', num2str(history_best_x)]);
        end

        disp(history_best_x);
        disp(dis_cal(history_best_x, dist_mat));
        alns_solution = history_best_x;
    end

    % 两边逐次修正算子（2-opt算法）
function path = successive_correction_operators(path, dist_mat)
    node = length(path);
    improved = true; % 标记是否还存在改进的可能性

    while improved
        improved = false;

        for i = 1:node-2
            for j = i+2:node-1
                % 计算交换节点前后的路径长度
                current_length = dist_mat(path(i), path(i+1)) + dist_mat(path(j), path(j+1));
                new_length = dist_mat(path(i), path(j)) + dist_mat(path(i+1), path(j+1));

                % 如果交换能够减少路径长度，则进行交换操作
                if new_length < current_length
                    path(i+1:j) = fliplr(path(i+1:j)); % 反转交换节点之间的路径
                    improved = true; % 标记存在改进
                end
            end
        end
    end
end


    % 计算TSP总距离
    function distance = dis_cal(path, dist_mat)
        distance = 0;
        for i = 1:length(path) - 1
            distance = distance + dist_mat(path(i), path(i + 1));
        end
        distance = distance + dist_mat(path(end), path(1));
    end

    % 读取Excel文件并准备数据
    function dist_mat = prepare_data(file_path)
        data = read_excel_file(file_path);
        city_location = process_node_info(data);
        dist_mat = city_distance(city_location);
    end

    % 绘制路径图
    function plot_tour(city_location, tour)
        num_cities = length(tour);
        city_coords = city_location(tour, :);
        city_coords = [city_coords; city_coords(1, :)];  % 添加起始城市以闭合路径

        figure;
        plot(city_coords(:, 1), city_coords(:, 2), 'ro-', 'MarkerSize', 8, 'LineWidth', 1.5);
        title('TSP Solution');
        xlabel('X Coordinate');
        ylabel('Y Coordinate');
        grid on;
    end

    % 指定Excel文件路径
    excel_file_path = 'att48.tsp.xlsx';  % 根据实际情况更新文件路径

    % 准备数据
    dist_mat = prepare_data(excel_file_path);

    % 输出距离矩阵到Excel文件
%     xlswrite('distance_matrix.xlsx', dist_mat);

    % 参数设置
    max_iter = 50;
    T = 100;
    a = 0.97;
    lambda_rate = 0.5;

    % 调用算法
    alns_solution = calc_by_alns(dist_mat, max_iter, T, a, lambda_rate);

    % 读取城市位置信息
    data = read_excel_file(excel_file_path);
    city_location = process_node_info(data);

    % 绘制路径图
    plot_tour(city_location, alns_solution);

end
